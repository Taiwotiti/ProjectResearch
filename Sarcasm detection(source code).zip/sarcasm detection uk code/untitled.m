clc
clear
% filename = "sonnets.txt";
% str = extractFileText(filename);
filename = "exampleSonnets.docx";
str = extractFileText(filename);

%View the second sonnet by extracting the text between the two titles "II" and "III".

start = " II" + newline;
fin = " III";
sonnet2 = extractBetween(str,start,fin);
sonnet2 = replace(sonnet2,[newline newline],newline);