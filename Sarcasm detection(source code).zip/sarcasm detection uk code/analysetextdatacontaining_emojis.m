
% Analyze Text Data Containing Emojis
emoji = compose("\xD83D\xDE0E");
codeUnits = dec2hex(char(emoji));
formatSpec = strjoin("\x" + codeUnits,"");
emoji = compose(formatSpec)

%Extract the text data in the file weekendUpdates.xlsx using readtable. The file weekendUpdates.xlsx contains status updates containing the hashtags "#weekend" and "#vacation".

filename = "weekendUpdates.xlsx";
tbl = readtable(filename,'TextType','string');
head(tbl)

%Extract the text data from the field TextData and view the first few status updates.

textData = tbl.TextData;
textData(1:5)

%Visualize the text data in a word cloud.
figure
wordcloud(textData);

% Filter Text Data by Emoji
% Identify the status updates containing a particular emoji using the contains function. Find the indices of the documents containing the "smiling face with sunglasses" emoji (😎 with code U+1F60E). This emoji comprises the two Unicode UTF16 code units "D83D" and "DE0E".

emoji = compose("\xD83D\xDE0E");
idx = contains(textData,emoji);
textDataSunglasses = textData(idx);
textDataSunglasses(1:5)

%Visualize the extracted text data in a word cloud.

figure
wordcloud(textDataSunglasses);

% Extract and Visualize Emojis
% Visualize all the emojis in text data using a word cloud.
% Extract the emojis. First tokenize the text using tokenizedDocument, and then view the first few documents.

documents = tokenizedDocument(textData);
documents(1:5)

%The tokenizedDocument function automatically detects emoji and assigns the token type "emoji". View the first few token details of the documents using the tokenDetails function.
tdetails = tokenDetails(documents);
head(tdetails)


%Visualize the emojis in a word cloud by extracting the tokens with token type "emoji" and inputting them into the wordcloud function.
idx = tdetails.Type == "emoji";
tokens = tdetails.Token(idx);
figure
wordcloud(tokens);
title("Emojis")