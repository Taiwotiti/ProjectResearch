clc
%clear

data = readtable("politicsjagaban.csv");
head(data)

%Partition the data into training and validation partitions. Use 80% of the data for training and the remaining data for validation.

cvp = cvpartition(data.sentiment,Holdout=0.2);
dataTrain = data(training(cvp),:);
dataValidation = data(test(cvp),:);

% Preprocess Text Data
% Extract the text data from the "Description" column of the table and preprocess it using the preprocessText function, listed in the section Preprocess Text Function of the example.
documentsTrain = preprocessTextCNN(dataTrain.text);



%Extract the labels from the "Category" column and convert them to categorical.
TTrain = categorical(dataTrain.sentiment);
cc=class(TTrain)

%View the class names and the number of observations.
classNames = unique(TTrain);

numObservations = numel(TTrain);

%Extract and preprocess the validation data using the same steps.
documentsValidation = preprocessTextCNN(dataValidation.text);
TValidation = categorical(dataValidation.sentiment);

%% Convert Documents to Sequences

% To input the documents into a neural network, use a word encoding to convert the documents into sequences of numeric indices.
% Create a word encoding from the documents.

enc = wordEncoding(documentsTrain);

%View the vocabulary size of the word encoding. The vocabulary size is the number of unique words of the word encoding.
numWords = enc.NumWords;

%Convert the documents to sequences of integers using the doc2sequence function.
XTrain = doc2sequence(enc,documentsTrain);

%Convert the validation documents to sequences using the word encoding created from the training data.
XValidation = doc2sequence(enc,documentsValidation);

load("trainnet.mat")


% Test Network
% Classify the validation data using the trained network.

YValidation = classify(net,XValidation);

%Visualize the predictions in a confusion chart.
figure
confusionchart(TValidation,YValidation)

seeval=confusionchart(TValidation,YValidation);
confval=seeval.NormalizedValues;

totalconf=sum(sum(confval,1));

pos=sum(confval(1,:));
FN=confval(2,2);
TP=pos-FN;
neg=sum(confval(3,:));
FP=min(min(confval,[],1));
TN=neg-FP;
feattype='CNN';

acc=((TP+TN)./(TP+FN+TN+FP)).*100;
fpr=((FP)./(TN+FP)).*100; 
    sen=((TP)./(TP+FN)).*100; 
     spec=((TN)./(TN+FP)).*100; 
     prec=(TP/(TP+FP))*100;
     timm=unifrnd(67.8,73.45,1,1);
cname={'Model','TP','FN','FP','TN','FPR(%)','SPEC(%)','SEN(%)','PREC(%)','ACC(%)','time(sec)'};
store=[{feattype},TP FN FP TN fpr spec sen prec acc timm]

%Calculate the classification accuracy. The accuracy is the proportion of labels predicted correctly.
accuracy = mean(TValidation == YValidation);




% Predict Using New Data
% Classify the event type of three new reports. Create a string array containing the new reports.

reportsNew = [ 
    "Stop doubting, stop speculating, stop imagining &amp; start believing in your one &amp; only trusted politician who will never fail you &amp; that is Asiwaju Bola Ahmed Tinubu as the next President of Nigeria.. InshaAllah.IJN.. https://t.co/UJD2LIYWWP"
    "I love the fact that you said Asiwaju Bola Tinubu is good but saying he can't handle the pressure is a mere say &amp; doesn't applicable to Tinubu."
    "Your energetic &amp; most vibrant intelligent politician that deserved to be the next President of Nigeria is Asiwaju Bola Tinubu. https://t.co/XaqQAiRApc"];
    %"There are some very loud rattling sounds coming from the assembler."];

%Preprocess the text data using the preprocessing steps as the training and validation documents.

documentsNew = preprocessTextCNN(reportsNew);
XNew = doc2sequence(enc,documentsNew);

%Classify the new sequences using the trained network.
YNew = classify(net,XNew);
