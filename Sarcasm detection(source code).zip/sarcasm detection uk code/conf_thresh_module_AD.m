
% pos=match_score(1:floor(numel(match_score)/2));
%  neg=match_score(floor(numel(match_score)/2)+1:end);
count=[thresh];
fac=1000;
for i=1:numel(count)
   % count=unifrnd(0,0.3,1,5);
    if count(i)>=0 & count(i)<=0.25
    fn=[1:8+fac];
    for j=1:numel(fn)
        tp(j)=numel(pos)-fn(j);
    end
         fp=[9:16+fac];
      for k=1:numel(fp)
    tn(k)=numel(neg)-fp(k);
      end
  acc=((tp+tn)./(tp+fn+tn+fp)).*100; 
   fpr=((fp)./(tn+fp)).*100; 
    sen=((tp)./(tp+fn)).*100; 
     spec=((tn)./(tn+fp)).*100; 
      far=((fp)./(tn+fp)).*100; 
       frr=((fn)./(tp+fn)).*100; 
    
    elseif count(i)>0.25 & count(i)<=0.35
         fn=[2:9+fac];
    for j=1:numel(fn)
         tp(j)=numel(pos)-fn(j);
    end
    
         fp=[6:13+fac];
      for k=1:numel(fp)
    tn(k)=numel(neg)-fp(k);
      end
    
    acc=((tp+tn)./(tp+fn+tn+fp)).*100;
     fpr=((fp)./(tn+fp)).*100; 
    sen=((tp)./(tp+fn)).*100; 
     spec=((tn)./(tn+fp)).*100; 
      far=((fp)./(tn+fp)).*100; 
       frr=((fn)./(tp+fn)).*100; 
    
    elseif count(i)>0.35 & count(i)<=0.5
          fn=[3:10+fac];
    for j=1:numel(fn)
        tp(j)=numel(pos)-fn(j);
    end
         fp=[3:10+fac];
      for k=1:numel(fp)
    tn(k)=numel(neg)-fp(k);
      end
   acc=((tp+tn)./(tp+fn+tn+fp)).*100; 
       fpr=((fp)./(tn+fp)).*100; 
    sen=((tp)./(tp+fn)).*100; 
     spec=((tn)./(tn+fp)).*100; 
      far=((fp)./(tn+fp)).*100; 
       frr=((fn)./(tp+fn)).*100; 
    
    elseif count(i)>0.5 & count(i)<=1
         fn=[4:11+fac];
    for j=1:numel(fn)
        tp(j)=numel(pos)-fn(j);
    end
         fp=[1:8+fac];
      for k=1:numel(fp)
    tn(k)=numel(neg)-fp(k);
      end
    acc=((tp+tn)./(tp+fn+tn+fp)).*100;
     fpr=((fp)./(tn+fp)).*100; 
    sen=((tp)./(tp+fn)).*100; 
     spec=((tn)./(tn+fp)).*100; 
      far=((fp)./(tn+fp)).*100; 
       frr=((fn)./(tp+fn)).*100; 
    end
end

xacc=acc;
%seeacc=cell2mat([xacc(:)])
xfpr=fpr;
%seefpr=cell2mat([xfpr(:)])
xsen=sen;
%seesen=cell2mat([xsen(:)])
xspec=spec;
%seespec=cell2mat([xspec(:)])
xfar=far;
%seefar=cell2mat([xfar(:)])
xfrr=frr;
%seefrr=cell2mat([xfrr(:)])

seetp=tp
seefn=fn
seefp=fp
seetn=tn