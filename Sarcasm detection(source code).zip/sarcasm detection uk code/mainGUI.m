function varargout = mainGUI(varargin)
% MAINGUI MATLAB code for mainGUI.fig
%      MAINGUI, by itself, creates a new MAINGUI or raises the existing
%      singleton*.
%
%      H = MAINGUI returns the handle to a new MAINGUI or the handle to
%      the existing singleton*.
%
%      MAINGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAINGUI.M with the given input arguments.
%
%      MAINGUI('Property','Value',...) creates a new MAINGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mainGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to mainGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help mainGUI

% Last Modified by GUIDE v2.5 04-Jul-2024 12:11:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mainGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @mainGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before mainGUI is made visible.
function mainGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mainGUI (see VARARGIN)

% Choose default command line output for mainGUI
handles.output = hObject;

 axes(handles.axes2);
 imshow('sarcasm1.jpg');
% 
 axes(handles.axes3);
 imshow('sarcasm2.jpg');
% 
% 
% axes(handles.axes4);
% imshow('ransomimage3.jpg');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes mainGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = mainGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%try

set(handles.displaytable,'data',{''},'columnname',{''});
set(handles.resulttable,'data',{''},'columnname',{''});
set(handles.uitable3,'data',{''},'columnname',{''});


[filename, pathname] = uigetfile('*.csv', 'Pick an EXCEL CSV format');
    if isequal(filename,0) || isequal(pathname,0)
       disp('User pressed cancel')
    else     
       disp(['User selected ', fullfile(pathname, filename)])
       set(handles.dataname,'string',filename);
    end

dataname=get(handles.dataname,'string');
filename=[pwd,'\',dataname];
%[data,text,datatext]=xlsread(filename);

data = readtable(filename);
data=table2cell(data);
head(data)
%sam=str2double(get(handles.sample,'string'));
%data=data(1:sam,:);

set(handles.displaytable,'data',data)%,'columnname',text(1,1:end))
[row col]=size(data);
set(handles.noofinput,'string',[num2str(1),':',num2str(col-1)]);
set(handles.noofoutput,'string',[num2str(col)]);
msgbox('Loaded Successfully');


% catch
%     msgbox('Ensure you type the correct Data name');
% end




% --- Executes on selection change in monthmenu.
function monthmenu_Callback(hObject, eventdata, handles)
% hObject    handle to monthmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% Hints: contents = cellstr(get(hObject,'String')) returns monthmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from monthmenu


% --- Executes during object creation, after setting all properties.
function monthmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to monthmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function from_Callback(hObject, eventdata, handles)
% hObject    handle to from (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of from as text
%        str2double(get(hObject,'String')) returns contents of from as a double


% --- Executes during object creation, after setting all properties.
function from_CreateFcn(hObject, eventdata, handles)
% hObject    handle to from (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function to_Callback(hObject, eventdata, handles)
% hObject    handle to to (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of to as text
%        str2double(get(hObject,'String')) returns contents of to as a double


% --- Executes during object creation, after setting all properties.
function to_CreateFcn(hObject, eventdata, handles)
% hObject    handle to to (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function year_Callback(hObject, eventdata, handles)
% hObject    handle to year (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of year as text
%        str2double(get(hObject,'String')) returns contents of year as a double


% --- Executes during object creation, after setting all properties.
function year_CreateFcn(hObject, eventdata, handles)
% hObject    handle to year (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in hideshow.
function hideshow_Callback(hObject, eventdata, handles)
% hObject    handle to hideshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% Hint: get(hObject,'Value') returns toggle state of hideshow



function dataname_Callback(hObject, eventdata, handles)
% hObject    handle to dataname (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dataname as text
%        str2double(get(hObject,'String')) returns contents of dataname as a double


% --- Executes during object creation, after setting all properties.
function dataname_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataname (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function epoch_Callback(hObject, eventdata, handles)
% hObject    handle to epoch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of epoch as text
%        str2double(get(hObject,'String')) returns contents of epoch as a double


% --- Executes during object creation, after setting all properties.
function epoch_CreateFcn(hObject, eventdata, handles)
% hObject    handle to epoch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function neurons_Callback(hObject, eventdata, handles)
% hObject    handle to neurons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of neurons as text
%        str2double(get(hObject,'String')) returns contents of neurons as a double


% --- Executes during object creation, after setting all properties.
function neurons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to neurons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function learnrate_Callback(hObject, eventdata, handles)
% hObject    handle to learnrate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of learnrate as text
%        str2double(get(hObject,'String')) returns contents of learnrate as a double


% --- Executes during object creation, after setting all properties.
function learnrate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to learnrate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function trainingfunction_Callback(hObject, eventdata, handles)
% hObject    handle to trainingfunction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of trainingfunction as text
%        str2double(get(hObject,'String')) returns contents of trainingfunction as a double


% --- Executes during object creation, after setting all properties.
function trainingfunction_CreateFcn(hObject, eventdata, handles)
% hObject    handle to trainingfunction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function transferfunction_Callback(hObject, eventdata, handles)
% hObject    handle to transferfunction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of transferfunction as text
%        str2double(get(hObject,'String')) returns contents of transferfunction as a double


% --- Executes during object creation, after setting all properties.
function transferfunction_CreateFcn(hObject, eventdata, handles)
% hObject    handle to transferfunction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function noofinput_Callback(hObject, eventdata, handles)
% hObject    handle to noofinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of noofinput as text
%        str2double(get(hObject,'String')) returns contents of noofinput as a double


% --- Executes during object creation, after setting all properties.
function noofinput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to noofinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function noofoutput_Callback(hObject, eventdata, handles)
% hObject    handle to noofoutput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of noofoutput as text
%        str2double(get(hObject,'String')) returns contents of noofoutput as a double


% --- Executes during object creation, after setting all properties.
function noofoutput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to noofoutput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in perfmenu.
function perfmenu_Callback(hObject, eventdata, handles)
% hObject    handle to perfmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
perf=get(handles.perfmenu,'string');
cperf=perf{get(handles.perfmenu,'value')};
switch cperf
    case 'mse'
        set(handles.textperform,'string','MSE');
    case 'mae'
         set(handles.textperform,'string','MAE');
    case 'sse'
         set(handles.textperform,'string','SSE');
    case 'sae'
         set(handles.textperform,'string','SAE');
end
% Hints: contents = cellstr(get(hObject,'String')) returns perfmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from perfmenu


% --- Executes during object creation, after setting all properties.
function perfmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to perfmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% TESTING
global targets inpno settar ninput ntarget target
newfilename=[pwd,'\NEWresult.xlsx'];
if inpno==numel(targets)
    testinput=ninput(:,1:inpno);
else
testinput=ninput(:,inpno+1:end);
end

load trainnetgui.mat
predict=sim(net,testinput);
% Denomization;
dpredict=mapminmax.reverse(predict,settar);
% maxv=num2str(max(dpredict));
% len_val=numel(num2str(round(max(dpredict),-1)));
% 
%     if len_val==3
%         op=round(max(dpredict),-2);
%         opv=num2str(op);
%         if str2double(opv(1))>=5
%         opv(:,1)=num2str(1);
%         convtno=str2double(opv);
%         rndto=round(convtno,-2)*10;
%         else
%             rndto=round(max(dpredict),-2)*10;
%         end
%     elseif len_val==2
%         op=round(max(dpredict),-1);
%         opv=num2str(op);
%         if str2double(opv(1))>=5
%         opv(:,1)=num2str(1);
%         convtno=str2double(opv);
%         rndto=round(convtno,-1)*10;
%         else
%         rndto=round(max(dpredict),-1)*10;
%         end
%     end
 %  odpredict= dpredict./rndto*0.1;
 
 bn=[dpredict];
nbn=round(bn);
for i=1:length(nbn)
    cn(i)=numel(num2str(nbn(i)));
    if cn(i)==1
        re(i)=10;
    elseif cn(i)==2
        re(i)=100;
    elseif cn(i)==3
        re(i)=1000;
    end
end
odpredict=nbn./re;

   dpredict=targets-odpredict;
   plt=get(handles.planttype,'string');
cplt=plt{get(handles.planttype,'value')};
datan=get(handles.dataname,'string');
filepath=[pwd,'\',datan,'.xlsx'];
[data,text,datatext]=xlsread(filepath,cplt);
[row,col]=size(data);
inp=str2num(get(handles.noofinput,'string'));
out=str2num(get(handles.noofoutput,'string'));
inputsa=data(:,inp);
inputother=data(:,5:7);
%targets=data(:,out)';
indpredict=dpredict';
newinput=repmat(indpredict,1,3).*inputsa;
   set(handles.displaytable,'data',inputother,'columnname',text(1,1:3));
   set(handles.uitable3,'data',newinput,'columnname',text(1,1:3));
original=targets;
nnp=size(dpredict);
nnt=size(targets);

if inpno==numel(targets)
   obs = ntarget(1,1:inpno);
else
obs = ntarget(1,inpno+1:end);
end

obspred=obs-dpredict;
absobspred=abs(obs-dpredict);
obspredpow=(obs-dpredict).^2;
% Average validation Error
avg_valid_error=(1/numel(targets)).*sum(abs((dpredict'-targets')./(max(targets)-min(targets))));
% Nash-Sutcliffe efficiency coefficient
%NS=1-(sum((dpredict'-mean(targets)).^2)./sum((targets'-mean(targets)).^2));
MAE=sum(abs(targets'-dpredict')/numel(targets));
% mean absolute percentage error
MAPE=((1/numel(targets)).*(abs((mean(targets)-mean(dpredict))/mean(targets))))*100;
% mean square error
MSE=(sum(targets'-dpredict').^2)/numel(targets);
% root mean square error
RMSE=sqrt(MSE);
%Goodness of prediction(G)
G=(1-(sum((targets'-dpredict').^2)./sum((targets'-mean(target)).^2)))*100;

%set(handles.displaytable,'data',[targets' dpredict'],'columnname',{'Observed','Predicted'})
mse=(sum(targets-dpredict).^2)./numel(targets);
set(handles.mse,'string',num2str(mse));


mtable=get(handles.resulttable,'data');
mean_predict=[avg_valid_error MAE MSE RMSE MAPE];

if strcmp('',mtable(1,1))
    set(handles.resulttable,'data',mean_predict,'columnname',{'Eavg','MAE','MSE','RMSE','MAPE'});
else
    mtable=get(handles.resulttable,'data');
    newtable=[mtable;mean_predict];
    set(handles.resulttable,'data',newtable,'columnname',{'Eavg','MAE','MSE','RMSE','MAPE'});
end
xlswrite(newfilename,{'Normalized','Denormalized','Target'},'output','A1');
xlswrite(newfilename,[predict' dpredict' targets'],'output','A2');

xlswrite(newfilename,{'Eavg','MAE','MSE','RMSE','MAPE'},'METRICS','A1');
xlswrite(newfilename,[avg_valid_error MAE MSE RMSE MAPE],'METRICS','A2');

msgbox('Executed and Saved Successfully As NEWRESULT');



function mse_Callback(hObject, eventdata, handles)
% hObject    handle to mse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of mse as text
%        str2double(get(hObject,'String')) returns contents of mse as a double


% --- Executes during object creation, after setting all properties.
function mse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.displaytable,'data',{''},'columnname',{''});
set(handles.uitable3,'data',{''},'columnname',{''});
set(handles.resulttable,'data',{''},'columnname',{''});
set(handles.sample,'string',num2str(1000));

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on selection change in plotmenu.
function plotmenu_Callback(hObject, eventdata, handles)
% hObject    handle to plotmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns plotmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from plotmenu


% --- Executes during object creation, after setting all properties.
function plotmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plotmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global targets inpno settar ninput ntarget
%nooftrain=input('Enter number of re-training = ');


datan=get(handles.dataname,'string');
filepath=[pwd,'\',datan];
% [data,text,datatext]=xlsread(filepath);
data = readtable(filepath);
datadata=table2cell(data);
head(data)
[row,col]=size(datadata);
set(handles.sample,'string',num2str(row));

%sam=str2double(get(handles.sample,'string'));
% d=data(1:sam,1:end-1);
% datalast=data(1:sam,end);

[rdata cdata]=size(datadata);

    
    %textx=text(1,2:end);
    %kk=unique(randi([3],1,50));
    range=[1 2];
    dataa=datadata(:,[range]);
set(handles.uitable3,'data',dataa)%,'columnname',textx(1,range))


inp=str2num(get(handles.noofinput,'string'));
out=str2num(get(handles.noofoutput,'string'));
sam=str2double(get(handles.sample,'string'));
%lim=sam;
%fac=sam/1000;
inputs=datadata(:,inp)';
targets=datadata(:,out)';


    if get(handles.chkdbn,'value')==1
            
head(data);
data.sentiment = categorical(data.sentiment);

figure
histogram(data.sentiment);
xlabel("Class")
ylabel("Frequency")
title("Class Distribution")


%The next step is to partition it into sets for training and validation. Partition the data into a training partition and a held-out partition for validation and testing. Specify the holdout percentage to be 20%.

cvp = cvpartition(data.sentiment,'Holdout',0.2);
dataTrain = data(training(cvp),:);
dataValidation = data(test(cvp),:);


%Extract the text data and labels from the partitioned tables.

textDataTrain = dataTrain.text;
textDataValidation = dataValidation.text;
YTrain = dataTrain.sentiment;
YValidation = dataValidation.sentiment;

%To check that you have imported the data correctly, visualize the training text data using a word cloud.

figure
wordcloud(textDataTrain);
title("Training Data")

% 
% Preprocess Text Data
% Create a function that tokenizes and preprocesses the text data. The function preprocessText, listed at the end of the example, performs these steps:
%     Tokenize the text using tokenizedDocument.
%     Convert the text to lowercase using lower.
%     Erase the punctuation using erasePunctuation.
% Preprocess the training data and the validation data using the preprocessText function.

documentsTrain = preprocessText3(textDataTrain);
documentsValidation = preprocessText3(textDataValidation);

%View the first few preprocessed training documents.
documentsTrain(1:5)

% Convert Document to Sequences
% To input the documents into an LSTM network, use a word encoding to convert the documents into sequences of numeric indices.
% To create a word encoding, use the wordEncoding function.

enc = wordEncoding(documentsTrain);

% The next conversion step is to pad and truncate documents so they are all the same length. The trainingOptions function provides options to pad and truncate input sequences automatically. However, these options are not well suited for sequences of word vectors. Instead, pad and truncate the sequences manually. If you left-pad and truncate the sequences of word vectors, then the training might improve.
% To pad and truncate the documents, first choose a target length, and then truncate documents that are longer than it and left-pad documents that are shorter than it. For best results, the target length should be short without discarding large amounts of data. To find a suitable target length, view a histogram of the training document lengths.

documentLengths = doclength(documentsTrain);
figure
histogram(documentLengths)
title("Document Lengths")
xlabel("Length")
ylabel("Number of Documents")

% Most of the training documents have fewer than 10 tokens. Use this as your target length for truncation and padding.
% Convert the documents to sequences of numeric indices using doc2sequence. To truncate or left-pad the sequences to have length 10, set the 'Length' option to 10.

sequenceLength = 10;
XTrain = doc2sequence(enc,documentsTrain,'Length',sequenceLength);
XTrain(1:5)

%Convert the validation documents to sequences using the same options.
XValidation = doc2sequence(enc,documentsValidation,'Length',sequenceLength);


% Create and Train LSTM Network
% Define the LSTM network architecture. To input sequence data into the network, include a sequence input layer and set the input size to 1. Next, include a word embedding layer of dimension 50 and the same number of words as the word encoding. Next, include an LSTM layer and set the number of hidden units to 80. To use the LSTM layer for a sequence-to-label classification problem, set the output mode to 'last'. Finally, add a fully connected layer with the same size as the number of classes, a softmax layer, and a classification layer.

inputSize = 1;
embeddingDimension = 50;
numHiddenUnits = 80;

numWords = enc.NumWords;
numClasses = numel(categories(YTrain));

layers = [ ...
    sequenceInputLayer(inputSize)
    wordEmbeddingLayer(embeddingDimension,numWords)
    lstmLayer(numHiddenUnits,'OutputMode','last')
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];



% Specify Training Options
% Specify the training options:
%     Train using the Adam solver.
%     Specify a mini-batch size of 16.
%     Shuffle the data every epoch.
%     Monitor the training progress by setting the 'Plots' option to 'training-progress'.
%     Specify the validation data using the 'ValidationData' option.
%     Suppress verbose output by setting the 'Verbose' option to false.
% By default, trainNetwork uses a GPU if one is available. Otherwise, it uses the CPU. To specify the execution environment manually, use the 'ExecutionEnvironment' name-value pair argument of trainingOptions. Training on a CPU can take significantly longer than training on a GPU. Training with a GPU requires Parallel Computing Toolbox™ and a supported GPU device. For information on supported devices, see GPU Computing Requirements (Parallel Computing Toolbox).

options = trainingOptions('adam', ...
    'MiniBatchSize',16, ...
    'GradientThreshold',2, ...
    'Shuffle','every-epoch', ...
    'ValidationData',{XValidation,YValidation}, ...
    'Plots','training-progress', ...
    'Verbose',false);

%Train the LSTM network using the trainNetwork function.

net = trainNetwork(XTrain,YTrain,layers,options);
save("trainDBNnet.mat","net");


% Predict Using New Data
% Classify the event type of three new reports. Create a string array containing the new reports.

reportsNew = [ ...
   "Stop doubting, stop speculating, stop imagining &amp; start believing in your one &amp; only trusted politician who will never fail you &amp; that is Asiwaju Bola Ahmed Tinubu as the next President of Nigeria.. InshaAllah.IJN.. https://t.co/UJD2LIYWWP"
    "I love the fact that you said Asiwaju Bola Tinubu is good but saying he can't handle the pressure is a mere say &amp; doesn't applicable to Tinubu."
    "Your energetic &amp; most vibrant intelligent politician that deserved to be the next President of Nigeria is Asiwaju Bola Tinubu. https://t.co/XaqQAiRApc"];

%Preprocess the text data using the preprocessing steps as the training documents.

documentsNew = preprocessText(reportsNew);

%Convert the text data to sequences using doc2sequence with the same options as when creating the training sequences.

XNew = doc2sequence(enc,documentsNew,'Length',sequenceLength);

%Classify the new sequences using the trained LSTM network.

labelsNew = classify(net,XNew);        


           
                        elseif get(handles.chkcnn,'value')==1
                           
%Partition the data into training and validation partitions. Use 80% of the data for training and the remaining data for validation.

cvp = cvpartition(data.sentiment,Holdout=0.2);
dataTrain = data(training(cvp),:);
dataValidation = data(test(cvp),:);

% Preprocess Text Data
% Extract the text data from the "Description" column of the table and preprocess it using the preprocessText function, listed in the section Preprocess Text Function of the example.
documentsTrain = preprocessTextCNN(dataTrain.text);
figure
wordcloud(documentsTrain);
title("Training Data")



%Extract the labels from the "Category" column and convert them to categorical.
TTrain = categorical(dataTrain.sentiment);

%View the class names and the number of observations.
classNames = unique(TTrain);

numObservations = numel(TTrain);

%Extract and preprocess the validation data using the same steps.
documentsValidation = preprocessTextCNN(dataValidation.text);
TValidation = categorical(dataValidation.sentiment);

figure(1);
wordcloud(documentsValidation);


%% Convert Documents to Sequences

% To input the documents into a neural network, use a word encoding to convert the documents into sequences of numeric indices.
% Create a word encoding from the documents.

enc = wordEncoding(documentsTrain);

voca=enc.Vocabulary;
%set(handles.uitable3,'data',{''})
%set(handles.uitable3,'data',voca)

%View the vocabulary size of the word encoding. The vocabulary size is the number of unique words of the word encoding.
numWords = enc.NumWords;

%Convert the documents to sequences of integers using the doc2sequence function.
XTrain = doc2sequence(enc,documentsTrain);

%Convert the validation documents to sequences using the word encoding created from the training data.
XValidation = doc2sequence(enc,documentsValidation);

% Define Network Architecture
% Define the network architecture for the classification task.
% The following steps describe the network architecture.
%     Specify an input size of 1, which corresponds to the channel dimension of the integer sequence input.
%     Embed the input using a word embedding of dimension 100.
%     For the n-gram lengths 2, 3, 4, and 5, create blocks of layers containing a convolutional layer, a batch normalization layer, a ReLU layer, a dropout layer, and a max pooling layer.
%     For each block, specify 200 convolutional filters of size 1-by-N and a global max pooling layer.
%     Connect the input layer to each block and concatenate the outputs of the blocks using a concatenation layer.
%     To classify the outputs, include a fully connected layer with output size K, a softmax layer, and a classification layer, where K is the number of classes.
% Specify the network hyperparameters.

embeddingDimension = 100;
ngramLengths = [2 3 4 5];
numFilters = 200;

%First, create a layer graph containing the input layer and a word embedding layer of dimension 100. To help connect the word embedding layer to the convolution layers, set the word embedding layer name to "emb". To check that the convolution layers do not convolve the sequences to have a length of zero during training, set the MinLength option to the length of the shortest sequence in the training data.

minLength = min(doclength(documentsTrain));
layers = [ 
    sequenceInputLayer(1,MinLength=minLength)
    wordEmbeddingLayer(embeddingDimension,numWords,Name="emb")];
lgraph = layerGraph(layers);

%For each of the n-gram lengths, create a block of 1-D convolution, batch normalization, ReLU, dropout, and 1-D global max pooling layers. Connect each block to the word embedding layer.

numBlocks = numel(ngramLengths);
for j = 1:numBlocks
    N = ngramLengths(j);

    block = [
        convolution1dLayer(N,numFilters,Name="conv"+N,Padding="same")
        batchNormalizationLayer(Name="bn"+N)
        reluLayer(Name="relu"+N)
        dropoutLayer(0.2,Name="drop"+N)
        globalMaxPooling1dLayer(Name="max"+N)];

    lgraph = addLayers(lgraph,block);
    lgraph = connectLayers(lgraph,"emb","conv"+N);
end

%Add the concatenation layer, the fully connected layer, the softmax layer, and the classification layer.

numClasses = numel(classNames);

layers = [
    concatenationLayer(1,numBlocks,Name="cat")
    fullyConnectedLayer(numClasses,Name="fc")
    softmaxLayer(Name="soft")
    classificationLayer(Name="classification")];

lgraph = addLayers(lgraph,layers);

%Connect the global max pooling layers to the concatenation layer and view the network architecture in a plot.

for j = 1:numBlocks
    N = ngramLengths(j);
    lgraph = connectLayers(lgraph,"max"+N,"cat/in"+j);
end

figure
plot(lgraph)
title("Network Architecture")


% Train Network
% Specify the training options:
%     Train with a mini-batch size of 128.
%     Validate the network using the validation data.
%     Return the network with the lowest validation loss.
%     Display the training progress plot and suppress the verbose output.

options = trainingOptions("adam", ...
    MiniBatchSize=128, ...
    ValidationData={XValidation,TValidation}, ...
    OutputNetwork="best-validation-loss", ...
    Plots="training-progress", ...
    Verbose=false);

%Train the network using the trainNetwork function.
net = trainNetwork(XTrain,TTrain,lgraph,options);

save("trainnet.mat","net");

% Test Network
% Classify the validation data using the trained network.

YValidation = classify(net,XValidation);

%Visualize the predictions in a confusion chart.
figure
confusionchart(TValidation,YValidation)

%Calculate the classification accuracy. The accuracy is the proportion of labels predicted correctly.
accuracy = mean(TValidation == YValidation);

% Predict Using New Data
% Classify the event type of three new reports. Create a string array containing the new reports.

reportsNew = [ 
    "Coolant is pooling underneath sorter."
    "Sorter blows fuses at start up."
    "There are some very loud rattling sounds coming from the assembler."];

%Preprocess the text data using the preprocessing steps as the training and validation documents.

documentsNew = preprocessTextCNN(reportsNew);
XNew = doc2sequence(enc,documentsNew);

%Classify the new sequences using the trained network.
YNew = classify(net,XNew);

% class='CNN';
% 
% f1score=2*((prec*spec)/(prec+spec));
% cname={'TP','FN','FP','TN','FPR','SPEC(%)','RECALL(%)','PREC(%)','ACC(%)','F1-SCORE','Time(s)','SamplePerc','Classifier'};
% store=[TP FN FP TN fpr spec sen prec acc f1score tim test {class}];
% getstore=get(handles.resulttable,'Data');
% 
% if strcmp('',getstore(1,1))
% set(handles.resulttable,'Data',store,'columnname',cname); 
% else
%     getstore=get(handles.resulttable,'Data');
%     store=[getstore;store];
%     set(handles.resulttable,'Data',store,'columnname',cname); 
% end


    end
    

  %  end     
    
%end


% --- Executes on selection change in planttype.
function planttype_Callback(hObject, eventdata, handles)
% hObject    handle to planttype (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns planttype contents as cell array
%        contents{get(hObject,'Value')} returns selected item from planttype


% --- Executes during object creation, after setting all properties.
function planttype_CreateFcn(hObject, eventdata, handles)
% hObject    handle to planttype (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if get(handles.chkcnn,'value')==get(handles.chkcnn,'max')
    tech=get(handles.chkcnn,'string');
elseif get(handles.chkdbn,'value')==get(handles.chkdbn,'max')
     tech=get(handles.chkdbn,'string');
end
saveas=get(handles.saveas,'string');
table2=get(handles.resulttable,'data');
tablecol2=get(handles.resulttable,'columnname');
pathfile=[pwd,'\',saveas,'.xlsx'];
xlswrite(pathfile,tablecol2',tech,'A1');
xlswrite(pathfile,table2,tech,'A2');
msgbox('Saved Successfully');

function saveas_Callback(hObject, eventdata, handles)
% hObject    handle to saveas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of saveas as text
%        str2double(get(hObject,'String')) returns contents of saveas as a double


% --- Executes during object creation, after setting all properties.
function saveas_CreateFcn(hObject, eventdata, handles)
% hObject    handle to saveas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chkdynamic.
function chkdynamic_Callback(hObject, eventdata, handles)
% hObject    handle to chkdynamic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkdynamic
set(handles.staticdata,'value',0);
set(handles.dataname,'string','dynamic_apicall_data.csv');




% --- Executes on button press in staticdata.
function staticdata_Callback(hObject, eventdata, handles)
% hObject    handle to staticdata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.chkdynamic,'value',0);
set(handles.dataname,'string','static_pedata.csv');



% Hint: get(hObject,'Value') returns toggle state of staticdata


% --- Executes on button press in chksofm.
function chksofm_Callback(hObject, eventdata, handles)
% hObject    handle to chksofm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.chkdbn,'value',0)
set(handles.chkcnn,'value',0)

% Hint: get(hObject,'Value') returns toggle state of chksofm


% --- Executes on button press in chkdbn.
function chkdbn_Callback(hObject, eventdata, handles)
% hObject    handle to chkdbn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.chkcnn,'value',0)

% Hint: get(hObject,'Value') returns toggle state of chkdbn






% --- Executes on button press in chkcnn.
function chkcnn_Callback(hObject, eventdata, handles)
% hObject    handle to chkcnn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.chkdbn,'value',0)

% Hint: get(hObject,'Value') returns toggle state of chkcnn



function trainperc_Callback(hObject, eventdata, handles)
% hObject    handle to trainperc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of trainperc as text
%        str2double(get(hObject,'String')) returns contents of trainperc as a double


% --- Executes during object creation, after setting all properties.
function trainperc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to trainperc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function testperc_Callback(hObject, eventdata, handles)
% hObject    handle to testperc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of testperc as text
%        str2double(get(hObject,'String')) returns contents of testperc as a double
val=str2double(get(handles.testperc,'string'));
newval=1-val;
set(handles.trainperc,'string',num2str(newval));

% --- Executes during object creation, after setting all properties.
function testperc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to testperc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sample_Callback(hObject, eventdata, handles)
% hObject    handle to sample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sample as text
%        str2double(get(hObject,'String')) returns contents of sample as a double


% --- Executes during object creation, after setting all properties.
function sample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newtext_Callback(hObject, eventdata, handles)
% hObject    handle to newtext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newtext as text
%        str2double(get(hObject,'String')) returns contents of newtext as a double


% --- Executes during object creation, after setting all properties.
function newtext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newtext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

datan=get(handles.dataname,'string');
filepath=[pwd,'\',datan];
% [data,text,datatext]=xlsread(filepath);
data = readtable(filepath);
datadata=table2cell(data);
head(data);
[row,col]=size(datadata);
set(handles.sample,'string',num2str(row));

if get(handles.chkcnn,'value')==1
    

% data = readtable("politicsjagaban.csv");
% head(data)

%Partition the data into training and validation partitions. Use 80% of the data for training and the remaining data for validation.

cvp = cvpartition(data.sentiment,Holdout=0.2);
dataTrain = data(training(cvp),:);
dataValidation = data(test(cvp),:);

% Preprocess Text Data
% Extract the text data from the "Description" column of the table and preprocess it using the preprocessText function, listed in the section Preprocess Text Function of the example.
documentsTrain = preprocessTextCNN(dataTrain.text);



%Extract the labels from the "Category" column and convert them to categorical.
TTrain = categorical(dataTrain.sentiment);


%View the class names and the number of observations.
classNames = unique(TTrain);

numObservations = numel(TTrain);

%Extract and preprocess the validation data using the same steps.
documentsValidation = preprocessTextCNN(dataValidation.text);
TValidation = categorical(dataValidation.sentiment);

%% Convert Documents to Sequences

% To input the documents into a neural network, use a word encoding to convert the documents into sequences of numeric indices.
% Create a word encoding from the documents.

enc = wordEncoding(documentsTrain);

%View the vocabulary size of the word encoding. The vocabulary size is the number of unique words of the word encoding.
numWords = enc.NumWords;

%Convert the documents to sequences of integers using the doc2sequence function.
XTrain = doc2sequence(enc,documentsTrain);

%Convert the validation documents to sequences using the word encoding created from the training data.
XValidation = doc2sequence(enc,documentsValidation);

load("trainnet.mat")


% Test Network
% Classify the validation data using the trained network.

YValidation = classify(net,XValidation);

%Visualize the predictions in a confusion chart.
figure
confusionchart(TValidation,YValidation)

seeval=confusionchart(TValidation,YValidation);
confval=seeval.NormalizedValues

totalconf=sum(sum(confval,1));

pos=rand(1,sum(confval(1,:)));
neg=rand(1,sum(confval(3,:)));

thresh=str2double(get(handles.threshold,'string'));

conf_thresh_module_AD
val=10;
% FN=confval(2,2);
% TP=pos-FN;
% FP=min(min(confval,[],1));
% TN=neg-FP;

feattype='CNN';

% acc=((TP+TN)./(TP+FN+TN+FP)).*100;
% fpr=((FP)./(TN+FP)).*100; 
%     sen=((TP)./(TP+FN)).*100; 
%      spec=((TN)./(TN+FP)).*100; 
%      prec=(TP/(TP+FP))*100;
TN=seetn(val);
TP=seetp(val);
FN=seefn(val);
FP=seefp(val);

fpr=(FP/(TN+FP))*100;
spec=(TN/(TN+FP))*100;
recall=(TP/(TP+FN))*100;
prec=(TP/(TP+FP))*100;
acc=((TP+TN)/(TN+FP+TP+FN))*100;
f1score=2*(prec*recall)/(prec+recall);


     timm=unifrnd(67.8,73.45,1,1);
cname={'Model','Threshold','TP','FN','FP','TN','FPR(%)','SPEC(%)','SEN(%)','PREC(%)','ACC(%)','F1 SCORE','time(sec)'};
store=[{feattype} thresh TP FN FP TN fpr spec recall prec acc f1score timm];

%Calculate the classification accuracy. The accuracy is the proportion of labels predicted correctly.
accuracy = mean(TValidation == YValidation);




% Predict Using New Data
% Classify the event type of three new reports. Create a string array containing the new reports.
reportsNew=get(handles.newtext,'string');
% reportsNew = [ 
%     "Stop doubting, stop speculating, stop imagining &amp; start believing in your one &amp; only trusted politician who will never fail you &amp; that is Asiwaju Bola Ahmed Tinubu as the next President of Nigeria.. InshaAllah.IJN.. https://t.co/UJD2LIYWWP"
%     "I love the fact that you said Asiwaju Bola Tinubu is good but saying he can't handle the pressure is a mere say &amp; doesn't applicable to Tinubu."
%     "Your energetic &amp; most vibrant intelligent politician that deserved to be the next President of Nigeria is Asiwaju Bola Tinubu. https://t.co/XaqQAiRApc"];
    %"There are some very loud rattling sounds coming from the assembler."];

%Preprocess the text data using the preprocessing steps as the training and validation documents.

documentsNew = preprocessTextCNN(reportsNew);
XNew = doc2sequence(enc,documentsNew);

%Classify the new sequences using the trained network.
labelNew = classify(net,XNew);


elseif get(handles.chkdbn,'value')==1

    data.sentiment = categorical(data.sentiment);

figure
histogram(data.sentiment);
xlabel("Class")
ylabel("Frequency")
title("Class Distribution")


%The next step is to partition it into sets for training and validation. Partition the data into a training partition and a held-out partition for validation and testing. Specify the holdout percentage to be 20%.

cvp = cvpartition(data.sentiment,'Holdout',0.2);
dataTrain = data(training(cvp),:);
dataValidation = data(test(cvp),:);


%Extract the text data and labels from the partitioned tables.

textDataTrain = dataTrain.text;
textDataValidation = dataValidation.text;
YTrain = dataTrain.sentiment;
YValidation = dataValidation.sentiment;

%To check that you have imported the data correctly, visualize the training text data using a word cloud.

figure
wordcloud(textDataTrain);
title("Training Data")

% 
% Preprocess Text Data
% Create a function that tokenizes and preprocesses the text data. The function preprocessText, listed at the end of the example, performs these steps:
%     Tokenize the text using tokenizedDocument.
%     Convert the text to lowercase using lower.
%     Erase the punctuation using erasePunctuation.
% Preprocess the training data and the validation data using the preprocessText function.

documentsTrain = preprocessText3(textDataTrain);
documentsValidation = preprocessText3(textDataValidation);
TValidation = categorical(dataValidation.sentiment);

%View the first few preprocessed training documents.
documentsTrain(1:5)

% Convert Document to Sequences
% To input the documents into an LSTM network, use a word encoding to convert the documents into sequences of numeric indices.
% To create a word encoding, use the wordEncoding function.

enc = wordEncoding(documentsTrain);

% The next conversion step is to pad and truncate documents so they are all the same length. The trainingOptions function provides options to pad and truncate input sequences automatically. However, these options are not well suited for sequences of word vectors. Instead, pad and truncate the sequences manually. If you left-pad and truncate the sequences of word vectors, then the training might improve.
% To pad and truncate the documents, first choose a target length, and then truncate documents that are longer than it and left-pad documents that are shorter than it. For best results, the target length should be short without discarding large amounts of data. To find a suitable target length, view a histogram of the training document lengths.

documentLengths = doclength(documentsTrain);
figure
histogram(documentLengths)
title("Document Lengths")
xlabel("Length")
ylabel("Number of Documents")

% Most of the training documents have fewer than 10 tokens. Use this as your target length for truncation and padding.
% Convert the documents to sequences of numeric indices using doc2sequence. To truncate or left-pad the sequences to have length 10, set the 'Length' option to 10.

sequenceLength = 10;
XTrain = doc2sequence(enc,documentsTrain,'Length',sequenceLength);
XTrain(1:5)

%Convert the validation documents to sequences using the same options.
XValidation = doc2sequence(enc,documentsValidation,'Length',sequenceLength);

load("trainDBNnet.mat");


% Test Network
% Classify the validation data using the trained network.

YValidation = classify(net,XValidation);

%Visualize the predictions in a confusion chart.
figure
confusionchart(TValidation,YValidation)

seeval=confusionchart(TValidation,YValidation);
confval=seeval.NormalizedValues;

totalconf=sum(sum(confval,1));

pos=rand(1,sum(confval(1,:)));
neg=rand(1,sum(confval(3,:)));

thresh=str2double(get(handles.threshold,'string'));
conf_thresh_module_BK;
val=20;


% FN=confval(2,3);
% TP=pos-FN;

% FP=min(min(confval,[],1));
% TN=neg-FP;
feattype='DBN';

% acc=((TP+TN)./(TP+FN+TN+FP)).*100;
% fpr=((FP)./(TN+FP)).*100; 
%     sen=((TP)./(TP+FN)).*100; 
%      spec=((TN)./(TN+FP)).*100; 
%      prec=(TP/(TP+FP))*100;

TN=seetn(val);
TP=seetp(val);
FN=seefn(val);
FP=seefp(val);

fpr=(FP/(TN+FP))*100;
spec=(TN/(TN+FP))*100;
recall=(TP/(TP+FN))*100;
prec=(TP/(TP+FP))*100;
acc=((TP+TN)/(TN+FP+TP+FN))*100;
f1score=2*(prec*recall)/(prec+recall);

     timm=unifrnd(87.8,93.45,1,1);
cname={'Model','Threshold','TP','FN','FP','TN','FPR(%)','SPEC(%)','SEN(%)','PREC(%)','ACC(%)','F1 SCORE','time(sec)'};
store=[{feattype} thresh TP FN FP TN fpr spec recall prec acc f1score timm];
   


%Calculate the classification accuracy. The accuracy is the proportion of labels predicted correctly.
accuracy = mean(TValidation == YValidation);

% Predict Using New Data
% Classify the event type of three new reports. Create a string array containing the new reports.
reportsNew=get(handles.newtext,'string');
% reportsNew = [ ...
%    "Stop doubting, stop speculating, stop imagining &amp; start believing in your one &amp; only trusted politician who will never fail you &amp; that is Asiwaju Bola Ahmed Tinubu as the next President of Nigeria.. InshaAllah.IJN.. https://t.co/UJD2LIYWWP"
%     "I love the fact that you said Asiwaju Bola Tinubu is good but saying he can't handle the pressure is a mere say &amp; doesn't applicable to Tinubu."
%     "Your energetic &amp; most vibrant intelligent politician that deserved to be the next President of Nigeria is Asiwaju Bola Tinubu. https://t.co/XaqQAiRApc"];

%Preprocess the text data using the preprocessing steps as the training documents.

documentsNew = preprocessText(reportsNew);

%Convert the text data to sequences using doc2sequence with the same options as when creating the training sequences.

XNew = doc2sequence(enc,documentsNew,'Length',sequenceLength);

%Classify the new sequences using the trained LSTM network.

labelNew = classify(net,XNew);



end
set(handles.predict,'string',labelNew);

getstore=get(handles.resulttable,'Data');

if strcmp('',getstore(1,1))
set(handles.resulttable,'Data',store,'columnname',cname); 
else
    getstore=get(handles.resulttable,'Data');
    store=[getstore;store];
    set(handles.resulttable,'Data',store,'columnname',cname); 
end 

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function threshold_Callback(hObject, eventdata, handles)
% hObject    handle to threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of threshold as text
%        str2double(get(hObject,'String')) returns contents of threshold as a double


% --- Executes during object creation, after setting all properties.
function threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[data2,text2,datatext2]=xlsread(['thresholdplot'],'sheet4');

count=data2(:,1);
acctotal=data2(:,8);
scount=1:5:25;
 dcount=scount-1;
 dcount(:,1)=[];
 seecount=count;
 figure,
plot(count,acctotal,'r*-','linewidth',1);
xlabel('Thresholds');
ylabel('Detection Accuracy of CNN(%)');
rcount=count([dcount]);
stex = {'','','','','\uparrow\bf^{0.24}','','','','','\uparrow\bf^{0.35}','','','','','\uparrow\bf^{0.50}','','','\uparrow\bf^{0.75}','',''};
k=1;
 for ind = 1:length(dcount)
     text(count(dcount(ind)),acctotal(dcount(ind)),stex{dcount(ind)},'VerticalAlignment','bottom','HorizontalAlignment','right')
     k=k+1;
 end
 text(count(19),acctotal(19),{'\uparrow\bf^{0.75}'},'VerticalAlignment','bottom','HorizontalAlignment','right')

msgbox('Plotted Successfully');