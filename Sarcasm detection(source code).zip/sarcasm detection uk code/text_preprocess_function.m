% Create a Preprocessing Function
% 
% It can be useful to create a function which performs preprocessing so you can prepare different collections of text data in the same way. For example, you can use a function so that you can preprocess new data using the same steps as the training data.
% 
% Create a function which tokenizes and preprocesses the text data so it can be used for analysis. The function preprocessText, performs the following steps:
% 
%     Tokenize the text using tokenizedDocument.
% 
%     Remove a list of stop words (such as "and", "of", and "the") using removeStopWords.
% 
%     Lemmatize the words using normalizeWords.
% 
%     Erase punctuation using erasePunctuation.
% 
%     Remove words with 2 or fewer characters using removeShortWords.
% 
%     Remove words with 15 or more characters using removeLongWords.
% 
% Use the example preprocessing function preprocessText to prepare the text data.

newText = "The sorting machine is making lots of loud noises.";
newDocuments = preprocessText(newText)

% Compare with Raw Data
% Compare the preprocessed data with the raw data.

rawDocuments = tokenizedDocument(textData);
rawBag = bagOfWords(rawDocuments)

%Calculate the reduction in data.
numWordsCleaned = cleanedBag.NumWords;
numWordsRaw = rawBag.NumWords;
reduction = 1 - numWordsCleaned/numWordsRaw

%Compare the raw data and the cleaned data by visualizing the two bag-of-words models using word clouds.

figure
subplot(1,2,1)
wordcloud(rawBag);
title("Raw Data")
subplot(1,2,2)
wordcloud(cleanedBag);
title("Cleaned Data")
