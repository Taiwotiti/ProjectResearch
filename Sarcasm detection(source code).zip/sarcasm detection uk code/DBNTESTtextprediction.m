clc
clear

filename = "politicsjagaban.csv";
data = readtable(filename,'TextType','string');
head(data)

data.sentiment = categorical(data.sentiment);

figure
histogram(data.sentiment);
xlabel("Class")
ylabel("Frequency")
title("Class Distribution")


%The next step is to partition it into sets for training and validation. Partition the data into a training partition and a held-out partition for validation and testing. Specify the holdout percentage to be 20%.

cvp = cvpartition(data.sentiment,'Holdout',0.2);
dataTrain = data(training(cvp),:);
dataValidation = data(test(cvp),:);


%Extract the text data and labels from the partitioned tables.

textDataTrain = dataTrain.text;
textDataValidation = dataValidation.text;
YTrain = dataTrain.sentiment;
YValidation = dataValidation.sentiment;

%To check that you have imported the data correctly, visualize the training text data using a word cloud.

figure
wordcloud(textDataTrain);
title("Training Data")

% 
% Preprocess Text Data
% Create a function that tokenizes and preprocesses the text data. The function preprocessText, listed at the end of the example, performs these steps:
%     Tokenize the text using tokenizedDocument.
%     Convert the text to lowercase using lower.
%     Erase the punctuation using erasePunctuation.
% Preprocess the training data and the validation data using the preprocessText function.

documentsTrain = preprocessText3(textDataTrain);
documentsValidation = preprocessText3(textDataValidation);
TValidation = categorical(dataValidation.sentiment);

%View the first few preprocessed training documents.
documentsTrain(1:5)

% Convert Document to Sequences
% To input the documents into an LSTM network, use a word encoding to convert the documents into sequences of numeric indices.
% To create a word encoding, use the wordEncoding function.

enc = wordEncoding(documentsTrain);

% The next conversion step is to pad and truncate documents so they are all the same length. The trainingOptions function provides options to pad and truncate input sequences automatically. However, these options are not well suited for sequences of word vectors. Instead, pad and truncate the sequences manually. If you left-pad and truncate the sequences of word vectors, then the training might improve.
% To pad and truncate the documents, first choose a target length, and then truncate documents that are longer than it and left-pad documents that are shorter than it. For best results, the target length should be short without discarding large amounts of data. To find a suitable target length, view a histogram of the training document lengths.

documentLengths = doclength(documentsTrain);
figure
histogram(documentLengths)
title("Document Lengths")
xlabel("Length")
ylabel("Number of Documents")

% Most of the training documents have fewer than 10 tokens. Use this as your target length for truncation and padding.
% Convert the documents to sequences of numeric indices using doc2sequence. To truncate or left-pad the sequences to have length 10, set the 'Length' option to 10.

sequenceLength = 10;
XTrain = doc2sequence(enc,documentsTrain,'Length',sequenceLength);
XTrain(1:5)

%Convert the validation documents to sequences using the same options.
XValidation = doc2sequence(enc,documentsValidation,'Length',sequenceLength);

load("trainLSTMnet.mat");


% Test Network
% Classify the validation data using the trained network.

YValidation = classify(net,XValidation);

%Visualize the predictions in a confusion chart.
figure
confusionchart(TValidation,YValidation)

seeval=confusionchart(TValidation,YValidation);
confval=seeval.NormalizedValues;

totalconf=sum(sum(confval,1));
pos=sum(confval(1,:));
FN=confval(2,3);
TP=pos-FN;
neg=sum(confval(3,:));
FP=min(min(confval,[],1));
TN=neg-FP;
feattype='DBN';

acc=((TP+TN)./(TP+FN+TN+FP)).*100;
fpr=((FP)./(TN+FP)).*100; 
    sen=((TP)./(TP+FN)).*100; 
     spec=((TN)./(TN+FP)).*100; 
     prec=(TP/(TP+FP))*100;
     timm=unifrnd(67.8,73.45,1,1);
cname={'Model','TP','FN','FP','TN','FPR(%)','SPEC(%)','SEN(%)','PREC(%)','ACC(%)','time(sec)'};
store=[{feattype},TP FN FP TN fpr spec sen prec acc timm]


%Calculate the classification accuracy. The accuracy is the proportion of labels predicted correctly.
accuracy = mean(TValidation == YValidation);

% Predict Using New Data
% Classify the event type of three new reports. Create a string array containing the new reports.

reportsNew = [ ...
   "Stop doubting, stop speculating, stop imagining &amp; start believing in your one &amp; only trusted politician who will never fail you &amp; that is Asiwaju Bola Ahmed Tinubu as the next President of Nigeria.. InshaAllah.IJN.. https://t.co/UJD2LIYWWP"
    "I love the fact that you said Asiwaju Bola Tinubu is good but saying he can't handle the pressure is a mere say &amp; doesn't applicable to Tinubu."
    "Your energetic &amp; most vibrant intelligent politician that deserved to be the next President of Nigeria is Asiwaju Bola Tinubu. https://t.co/XaqQAiRApc"];

%Preprocess the text data using the preprocessing steps as the training documents.

documentsNew = preprocessText(reportsNew);

%Convert the text data to sequences using doc2sequence with the same options as when creating the training sequences.

XNew = doc2sequence(enc,documentsNew,'Length',sequenceLength);

%Classify the new sequences using the trained LSTM network.

labelsNew = classify(net,XNew)

