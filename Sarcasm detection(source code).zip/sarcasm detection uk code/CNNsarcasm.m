% Step 1: Load and preprocess the dataset
% Assume you have a dataset with labeled text data, where each row contains a text review and its sentiment label (positive or negative).

% Load your dataset, and split it into training and testing sets
data = importdata('sentiment_data.csv'); % Replace 'sentiment_data.csv' with your dataset file
X = data.text; % Input text data
Y = data.sentiment; % Sentiment labels (1 for positive, 0 for negative)

% Tokenize and preprocess the text data (you may need to install the Text Analytics Toolbox)
documents = tokenizedDocument(X);
documents = preprocessText(documents);

% Split the data into training and testing sets
cvp = cvpartition(Y, 'Holdout', 0.2); % 80% training, 20% testing
XTrain = documents(cvp.training);
YTrain = Y(cvp.training);
XTest = documents(cvp.test);
YTest = Y(cvp.test);

% Step 2: Create a CNN model
layers = [
    sequenceInputLayer(50) % Adjust the input size as needed
    wordEmbeddingLayer(50) % You can change the embedding dimension
    convolution2dLayer(3, 100) % Convolutional layer with 100 filters
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)
    fullyConnectedLayer(2) % 2 classes (positive and negative)
    softmaxLayer
    classificationLayer
];

% Step 3: Specify training options
options = trainingOptions('adam', ...
    'Plots', 'training-progress', ...
    'ValidationData', {XTest, YTest}, ...
    'MaxEpochs', 10, ...
    'MiniBatchSize', 64);

% Step 4: Train the CNN model
net = trainNetwork(XTrain, YTrain, layers, options);

% Step 5: Evaluate the model
YTestPredicted = classify(net, XTest);
accuracy = sum(YTestPredicted == YTest) / numel(YTest);

disp(['Test Accuracy: ', num2str(accuracy * 100), '%']);
