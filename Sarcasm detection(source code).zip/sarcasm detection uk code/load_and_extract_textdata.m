%Load and Extract Text Data

%Load the example data. The file factoryReports.csv contains factory reports, including a text description and categorical labels for each event.
filename = "factoryReports.csv";
data = readtable(filename,'TextType','string');

%Extract the text data from the field Description, and the label data from the field Category.
textData = data.Description;
labels = data.Category;
textData(1:10);


% Create Tokenized Documents
% Create an array of tokenized documents.
cleanedDocuments = tokenizedDocument(textData);
cleanedDocuments(1:10)

%To improve lemmatization, add part of speech details to the documents using addPartOfSpeechDetails. Use the addPartOfSpeech function before removing stop words and lemmatizing.
cleanedDocuments = addPartOfSpeechDetails(cleanedDocuments);

%Words like "a", "and", "to", and "the" (known as stop words) can add noise to data. Remove a list of stop words using the removeStopWords function. Use the removeStopWords function before using the normalizeWords function.
cleanedDocuments = removeStopWords(cleanedDocuments);
cleanedDocuments(1:10)

%Lemmatize the words using normalizeWords.
cleanedDocuments = normalizeWords(cleanedDocuments,'Style','lemma');
cleanedDocuments(1:10)

%Erase the punctuation from the documents.
cleanedDocuments = erasePunctuation(cleanedDocuments);
cleanedDocuments(1:10)

%Remove words with 2 or fewer characters, and words with 15 or greater characters.
cleanedDocuments = removeShortWords(cleanedDocuments,2);
cleanedDocuments = removeLongWords(cleanedDocuments,15);
cleanedDocuments(1:10)

%Create Bag-of-Words Model
%Create a bag-of-words model.
cleanedBag = bagOfWords(cleanedDocuments)

%Remove words that do not appear more than two times in the bag-of-words model.
cleanedBag = removeInfrequentWords(cleanedBag,2)

%Remove empty documents from the bag-of-words model and the corresponding labels from labels.
[cleanedBag,idx] = removeEmptyDocuments(cleanedBag);
labels(idx) = [];
cleanedBag